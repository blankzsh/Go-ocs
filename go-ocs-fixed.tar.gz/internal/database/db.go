package database

import (
	"database/sql"
	"fmt"
	"log"
	"ai-ocs/internal/models"

	_ "github.com/go-sql-driver/mysql"
)

var db *sql.DB

// InitDB 初始化数据库连接
func InitDB(config *models.Config) error {
	// 构建MySQL连接字符串
	mysqlConfig := config.MySQLConfig
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=utf8mb4&parseTime=True&loc=Local",
		mysqlConfig.User,
		mysqlConfig.Password,
		mysqlConfig.Host,
		mysqlConfig.Port,
		mysqlConfig.Database)

	var err error
	db, err = sql.Open("mysql", dsn)
	if err != nil {
		return fmt.Errorf("无法打开数据库: %v", err)
	}

	// 设置连接池参数
	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(25)
	db.SetConnMaxLifetime(5 * 60)

	// 测试连接
	if err := db.Ping(); err != nil {
		return fmt.Errorf("无法连接到数据库: %v", err)
	}

	// 初始化表结构
	if err := initSchema(); err != nil {
		return fmt.Errorf("初始化数据库表失败: %v", err)
	}

	log.Println("数据库连接成功")
	return nil
}

// initSchema 初始化数据库表结构
func initSchema() error {
	// 创建问题答案表
	createTableSQL := `
	CREATE TABLE IF NOT EXISTS question_answer (
		id INTEGER PRIMARY KEY AUTO_INCREMENT,
		question TEXT NOT NULL,
		answer TEXT NOT NULL,
		options TEXT,
		type TEXT,
		created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
	) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`

	_, err := db.Exec(createTableSQL)
	if err != nil {
		return err
	}

	// 添加索引以加快查询速度
	createIndexSQL := `CREATE INDEX IF NOT EXISTS idx_question ON question_answer(question);`
	_, err = db.Exec(createIndexSQL)
	if err != nil {
		return err
	}

	log.Println("数据库表初始化成功")
	return nil
}

// GetDB 获取数据库连接实例
func GetDB() *sql.DB {
	return db
}