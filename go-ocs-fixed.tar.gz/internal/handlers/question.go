package handlers

import (
	"ai-ocs/internal/ai"
	"ai-ocs/internal/database"
	"ai-ocs/internal/models"
	"database/sql"
	"encoding/json"
	"log"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

// SearchAnswerResponse 搜索答案响应结构
type SearchAnswerResponse struct {
	Success bool `json:"success"`
	Data    struct {
		Code    int    `json:"code"`
		Data    string `json:"data"`
		Msg     string `json:"msg"`
		Source  string `json:"source,omitempty"`
	} `json:"data,omitempty"`
	Error string `json:"error,omitempty"`
}

// SearchAnswer 处理搜索答案请求
func SearchAnswer(config *models.Config) gin.HandlerFunc {
	return func(c *gin.Context) {
		// 获取查询参数
		title := strings.TrimSpace(c.Query("title"))
		options := c.Query("options")
		questionType := c.Query("type")

		// 检查必需参数
		if title == "" {
			c.JSON(http.StatusBadRequest, SearchAnswerResponse{
				Success: false,
				Error:   "缺少题目参数",
			})
			return
		}

		// 连接数据库
		db := database.GetDB()
		if db == nil {
			c.JSON(http.StatusInternalServerError, SearchAnswerResponse{
				Success: false,
				Error:   "数据库连接失败",
			})
			return
		}

		// 查询数据库中是否已存在答案
		var answer string
		err := db.QueryRow("SELECT answer FROM question_answer WHERE question = ? LIMIT 1", title).Scan(&answer)
		if err != nil && err != sql.ErrNoRows {
			log.Printf("数据库查询错误: %v", err)
		}

		// 如果数据库中存在答案，直接返回
		if err == nil && answer != "" {
			c.JSON(http.StatusOK, SearchAnswerResponse{
				Success: true,
				Data: struct {
					Code   int    `json:"code"`
					Data   string `json:"data"`
					Msg    string `json:"msg"`
					Source string `json:"source,omitempty"`
				}{
					Code:   1,
					Data:   answer,
					Msg:    "来于本地数据库题库",
					Source: "public",
				},
			})
			return
		}

		// 确定使用哪个API密钥
		apiKey := config.APIKey
		if config.Platform == "aliyun" {
			apiKey = config.AliyunAPIKey
		}

		// 使用AI获取答案
		aiAnswer, err := ai.QueryLargeModel(title, options, questionType, config.Platform, apiKey, config.AliyunModel)
		if err != nil {
			log.Printf("AI调用错误: %v", err)
		}

		// 处理AI返回的答案
		if aiAnswer != "" && !strings.Contains(aiAnswer, "API调用失败") && !strings.Contains(aiAnswer, "无法从API获取答案") {
			// 尝试解析JSON格式的答案
			if strings.Contains(aiAnswer, "{") && strings.Contains(aiAnswer, "}") {
				startIdx := strings.Index(aiAnswer, "{")
				endIdx := strings.LastIndex(aiAnswer, "}") + 1
				if startIdx >= 0 && endIdx > startIdx {
					jsonStr := aiAnswer[startIdx:endIdx]

					// 尝试解析JSON
					var answerMap map[string]interface{}
					if err := json.Unmarshal([]byte(jsonStr), &answerMap); err == nil {
						// 提取answer或anwser字段
						if ans, ok := answerMap["answer"].(string); ok {
							aiAnswer = ans
						} else if ans, ok := answerMap["anwser"].(string); ok {
							aiAnswer = ans
						}
					}
				}
			}

			// 保存到数据库
			if aiAnswer != "" {
				_, err := db.Exec("INSERT INTO question_answer (question, answer, options, type) VALUES (?, ?, ?, ?)",
					title, aiAnswer, options, questionType)
				if err != nil {
					log.Printf("保存答案到数据库失败: %v", err)
				}

				// 返回AI答案
				c.JSON(http.StatusOK, SearchAnswerResponse{
					Success: true,
					Data: struct {
						Code   int    `json:"code"`
						Data   string `json:"data"`
						Msg    string `json:"msg"`
						Source string `json:"source,omitempty"`
					}{
						Code: 1,
						Data: aiAnswer,
						Msg:  "AI回答",
					},
				})
				return
			}
		}

		// 未找到答案
		c.JSON(http.StatusOK, SearchAnswerResponse{
			Success: true,
			Data: struct {
				Code   int    `json:"code"`
				Data   string `json:"data"`
				Msg    string `json:"msg"`
				Source string `json:"source,omitempty"`
			}{
				Code: 0,
				Data: "",
				Msg:  "未找到答案",
			},
		})
	}
}