package models

import (
	"encoding/json"
	"os"
)

// Config 应用配置结构体
type Config struct {
	Host         string `json:"host"`
	Port         int    `json:"port"`
	APIKey       string `json:"api_key"`
	Platform     string `json:"platform"`
	AliyunAPIKey string `json:"aliyun_api_key"`
	AliyunModel  string `json:"aliyun_model"`
	// MySQL配置
	MySQLConfig MySQLConfig `json:"mysql"`
}

// MySQLConfig MySQL数据库配置
type MySQLConfig struct {
	Host     string `json:"host"`
	Port     int    `json:"port"`
	User     string `json:"user"`
	Password string `json:"password"`
	Database string `json:"database"`
}

// LoadConfig 从文件加载配置
func LoadConfig(filePath string) (*Config, error) {
	data, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	var config Config
	err = json.Unmarshal(data, &config)
	if err != nil {
		return nil, err
	}

	// 设置默认值
	if config.Platform == "" {
		config.Platform = "siliconflow"
	}

	if config.AliyunModel == "" {
		config.AliyunModel = "qwen-plus"
	}

	// 设置MySQL默认值
	if config.MySQLConfig.Host == "" {
		config.MySQLConfig.Host = "localhost"
	}

	if config.MySQLConfig.Port == 0 {
		config.MySQLConfig.Port = 3306
	}

	if config.MySQLConfig.User == "" {
		config.MySQLConfig.User = "root"
	}

	if config.MySQLConfig.Database == "" {
		config.MySQLConfig.Database = "question_bank"
	}

	return &config, nil
}
